import java.util.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;        


public class GraphGUI
{
    
    private JGraph graph; //The graph to be displayed
    private JLabel instr; //Label for the input mode instruction

    InputMode mode = InputMode.ADD_NODES; //Input mode
    Point posMouse; //position of last mouse event
    Point posHead = null; //position of head node
    Point posTail = null; // position of tail node

    //Determines order in which events will occur for creating and displaying the GUI  
    public static void main(String[] args)
    {
        final GraphGUI GUI = new GraphGUI();
        javax.swing.SwingUtilities.invokeLater(new Runnable()
        {
                public void run()
                {
                    GUI.createAndShowGUI();
                }
        });
    }

    // Defines the GUI frame
    public void createAndShowGUI()
    {

        JFrame.setDefaultLookAndFeelDecorated(true);
        // Create and set up the window frame.
        JFrame frame = new JFrame("Graph GUI");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        // Add components
        createComponents(frame);
        // Display the window.
        frame.pack();
        frame.setVisible(true);
    }

    // create and add content in the window frame
    public void createComponents(JFrame frame)
    {
        Container pane = frame.getContentPane();
        pane.setLayout(new FlowLayout());
        JPanel panel1 = new JPanel();
        panel1.setLayout(new BorderLayout());
        graph = new JGraph();
        PointMouseListener pml = new PointMouseListener();
        graph.addMouseListener(pml);
        graph.addMouseMotionListener(pml);
        panel1.add(graph);
        instr = new JLabel("Click to add new nodes; drag to move.");
        panel1.add(instr,BorderLayout.NORTH);
        pane.add(panel1);

        JPanel panel2 = new JPanel();
        panel2.setLayout(new GridLayout(2,2));

        JButton addNodeButton = new JButton("Add/Move Nodes");
        panel2.add(addNodeButton);
        addNodeButton.addActionListener(new AddNodeListener());
        
        JButton rmvNodeButton = new JButton("Remove Nodes");
        panel2.add(rmvNodeButton);
        rmvNodeButton.addActionListener(new RmvNodeListener());

        JButton addEdgeButton = new JButton("Add Edges");
        panel2.add(addEdgeButton);
        addEdgeButton.addActionListener(new AddEdgeListener());

        JButton rmvEdgeButton = new JButton("Remove Edges");
        panel2.add(rmvEdgeButton);
        rmvEdgeButton.addActionListener(new RmvEdgeListener());
        pane.add(panel2);
    }

    /*
      Returns a point found within the painted region of node at the mouse location or null if none
     
       x : the x coordinate of the location
       y : the y coordinate of the location
       returns: a point from the graph if there is one covering mouse location otherwise NULL
    */
    public Point isCoverPoint(int x, int y)
    {
        Point pointFound = null;
        Graph<DisplayNode,DisplayEdge> g = graph.getGraph();
        for(int i=0; i<g.numNodes(); i++) 
        {
            Point p = g.getNode(i).getData().getPosition();
            double d = p.distance((double)x, (double)y);
            if (d < 20)
                pointFound = p;
        }
        return pointFound;
    }

    //enumeration for storing the input types
    enum InputMode
    {
        ADD_NODES, RMV_NODES, ADD_EDGES, RMV_EDGES,
    }

    // Listener for AddNode button
    private class AddNodeListener implements ActionListener
    {
        // Event handler for AddNode button
        public void actionPerformed(ActionEvent e)
        {
            mode = InputMode.ADD_NODES;
            instr.setText("Click to add new node; drag to move");
        }
    }

    // Listener for RmvNode button
    private class RmvNodeListener implements ActionListener
    {
        // Event handler for RmvNode button
        public void actionPerformed(ActionEvent e)
        {
            mode = InputMode.RMV_NODES;
            instr.setText("Click to remove node");
        }
    }

    // Listener for AddEdge button 
    private class AddEdgeListener implements ActionListener
    {
        // Event handler for AddEdge button
        public void actionPerformed(ActionEvent e)
        {
            mode = InputMode.ADD_EDGES;
            instr.setText("Click on two existing nodes to add a new edge");
        }
    }

    // Listener for RmvEdge button
    private class RmvEdgeListener implements ActionListener
    {
        // Event handler for RmvEdge button
        public void actionPerformed(ActionEvent e)
        {
            mode = InputMode.RMV_EDGES;
            instr.setText("Click to remove edges");
        }
    }

    
    // Mouse listener for point on the graph
    private class PointMouseListener extends MouseAdapter implements MouseMotionListener
    {

        // Reacts to click event depending on mode
        public void mouseClicked(MouseEvent e)
        {
            int mouseX = e.getX();
            int mouseY = e.getY();
            Point nearBy = isCoverPoint(mouseX, mouseY);
            switch (mode) {
            case ADD_NODES:
                // If the click is not in the region of highlight of an existing point, create a new one and add it to the graph.
                // Otherwise, emit a beep, as shown below:
                if(nearBy == null)
                {
                    Point newPoint = new Point(mouseX, mouseY);
                    String data = JOptionPane.showInputDialog("Please input data for node: ");
                    if (data != null)
                        graph.getGraph().addNode(new DisplayNode(newPoint, data, new Color(40,188,237)));
                }
                else
                    Toolkit.getDefaultToolkit().beep();
                break;
            case RMV_NODES:
                // If the click is on top of an existing node, remove it from the graph's list of nodes.
                // Otherwise, emit a beep.
                if(nearBy != null)
                {
                    for (int i=0; i<graph.getGraph().numNodes(); i++)
                    {
                        if (graph.getGraph().getNode(i).getData().getPosition() == nearBy)
                            graph.getGraph().removeNode(graph.getGraph().getNode(i));
                    }
                }
                else
                    Toolkit.getDefaultToolkit().beep();
                break;
            case ADD_EDGES:
                // If two nodes are selected by clicking(mouse), add an edge in between them
                if (nearBy != null)
                {
                    if(posHead == null)
                        posHead = nearBy;
                    else if ((posHead != null && posTail == null) && (!nearBy.equals(posHead)))
                    {
                        posTail = nearBy;
                        Graph<DisplayNode,DisplayEdge>.Node head = null;
                        Graph<DisplayNode,DisplayEdge>.Node tail =  null;
                        for (int i=0; i<graph.getGraph().numNodes(); i++)
                        {
                            if (graph.getGraph().getNode(i).getData().getPosition() == posHead)
                                head = graph.getGraph().getNode(i);
                            else if (graph.getGraph().getNode(i).getData().getPosition() == posTail)
                                tail = graph.getGraph().getNode(i);
                        }
                    }
                }
                break;
            case RMV_EDGES:
                // If two nodes are slected(by clicking), remove the edge in between them
                if (nearBy != null)
                {
                    if(posHead == null)
                        posHead = nearBy;
                    else if (posHead != null && posTail == null) 
                    {
                        posTail = nearBy;
                        Graph<DisplayNode,DisplayEdge>.Node head = null;
                        Graph<DisplayNode,DisplayEdge>.Node tail =  null;
                        for (int i=0; i<graph.getGraph().numNodes(); i++) 
                        {
                            if (graph.getGraph().getNode(i).getData().getPosition() == posHead) 
                                head = graph.getGraph().getNode(i);
                            else if (graph.getGraph().getNode(i).getData().getPosition() == posTail)
                                tail = graph.getGraph().getNode(i);
                        }
                        graph.getGraph().removeEdge(head, tail);
                        posHead = null;
                        posTail = null;
                    }
                }
                break;
            }
            graph.repaint();
        }

        // picks point under mouse remaining pressed event - maybe a drag
        public void mousePressed(MouseEvent e) 
        {
            // pick point under mouse, if any
            posMouse = isCoverPoint(e.getX(), e.getY());
        }

        //reacts to mouse button release event 
        public void mouseReleased(MouseEvent e) 
        {
            // Clear record of point under mouse, if any
            posMouse = null;
        }

        // reacts to mouse dragging event
        public void mouseDragged(MouseEvent e) 
        {
            // If mode allows point motion, and there is a point under the mouse, 
            // then change its coordinates to the current location of mouse & update display
            if (mode == InputMode.ADD_NODES && posMouse != null)
            {
                posMouse.setLocation(e.getX(), e.getY());
                graph.repaint();
            }
        }
        // Empty but necessary to comply with MouseMotionListener interface.
        public void mouseMoved(MouseEvent e) {}
    }
}