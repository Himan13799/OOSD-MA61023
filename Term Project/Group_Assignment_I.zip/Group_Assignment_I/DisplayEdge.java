import java.awt.*;
import javax.swing.*;

// The edge class to store the parameters related to an edge and manage them
public class DisplayEdge
{
	String label;
	Color color;
	
	public DisplayEdge(String label, Color color)
	{
		this.label = label;
		this.color = color;
	}

	public String getLabel()
	{
		return label;
	}

	public Color getColor()
	{
		return color;
	}
	
	public void setLabel(String label)
	{
		this.label = label;
	}

	public void setColor(Color color)
	{
		this.color = color;
	}
}
