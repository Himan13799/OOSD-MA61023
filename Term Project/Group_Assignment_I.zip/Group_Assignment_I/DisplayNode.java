import java.awt.*;
import javax.swing.*;     

// Class for display and attributes of a Node
public class DisplayNode 
{
	Point position; // position on screen panel 1 of GUI frame
	String label; //label example: point 'a'
	Color color;

	public DisplayNode(Point position, String label, Color color) 
	{
		this.position = position;
		this.label = label;
		this.color = color;
	} 

	public Point getPosition() 
	{
		return position;
	}

	public String getLabel() 
	{
		return label;
	}

	public Color getColor() 
	{
		return color;
	}

	public void setPosition(Point position) 
	{
		this.position = position;
	}

	public void setLabel(String label) 
	{
		this.label = label;
	}

	public void setColor(Color color) 
	{
		this.color = color;
	}
}
